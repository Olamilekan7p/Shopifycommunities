import { randomUUID } from 'node:crypto';
import { requireSameOrigin } from '../lib/auth.js';
import { hasRedisConfig, redisCommand } from '../lib/redis.js';
import { allowRequest } from '../lib/rate-limit.js';

const text = (value, max = 2000) => String(value || '').trim().slice(0, max);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' });
  if (!requireSameOrigin(req, res)) return;
  if (!hasRedisConfig()) return res.status(503).json({ error: 'Store submissions are temporarily unavailable.' });
  const body = req.body || {};
  const name = text(body.name, 120);
  const email = text(body.email, 254).toLowerCase();
  const storeName = text(body.storeName, 160);
  const website = text(body.website, 500);
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !storeName) return res.status(400).json({ error: 'Complete your name, email, and store name.' });
  if (body.contactConsent !== 'yes') return res.status(400).json({ error: 'Consent is required before we can contact you.' });
  try {
    const url = new URL(website);
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Invalid website.');
  } catch {
    return res.status(400).json({ error: 'Enter a valid store website.' });
  }

  try {
    if (!await allowRequest(req, 'store-attempts', 5, 60 * 60)) return res.status(429).json({ error: 'Too many store submissions from this connection. Please try again later.' });
    await redisCommand('LPUSH', 'sdc:submissions', JSON.stringify({
      id: randomUUID(), name, email, storeName, website,
      category: text(body.category, 100),
      shipping: text(body.shipping, 300),
      delivery: text(body.delivery, 200),
      offers: text(body.offers, 1000),
      products: text(body.products),
      notes: text(body.notes),
      submittedAt: new Date().toISOString(),
      status: 'New'
    }));
    return res.status(201).json({ ok: true });
  } catch {
    return res.status(503).json({ error: 'Store submissions are temporarily unavailable.' });
  }
}
