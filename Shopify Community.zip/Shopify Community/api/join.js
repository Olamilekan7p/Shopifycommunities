import { randomUUID } from 'node:crypto';
import { requireSameOrigin } from '../lib/auth.js';
import { hasRedisConfig, redisCommand } from '../lib/redis.js';
import { allowRequest } from '../lib/rate-limit.js';

const text = (value, max = 2000) => String(value || '').trim().slice(0, max);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' });
  if (!requireSameOrigin(req, res)) return;
  if (!hasRedisConfig()) return res.status(503).json({ error: 'Membership sign-up is temporarily unavailable.' });
  const body = req.body || {};
  const name = text(body.name, 120);
  const email = text(body.email, 254).toLowerCase();
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a name and valid email address.' });

  try {
    if (!await allowRequest(req, 'join-attempts', 10, 60 * 60)) return res.status(429).json({ error: 'Too many sign-ups from this connection. Please try again later.' });
    await redisCommand('LPUSH', 'sdc:members', JSON.stringify({
      id: randomUUID(),
      name,
      email,
      interests: text(body.interests),
      joinedAt: new Date().toISOString()
    }));
    return res.status(201).json({ ok: true });
  } catch {
    return res.status(503).json({ error: 'Membership sign-up is temporarily unavailable.' });
  }
}
