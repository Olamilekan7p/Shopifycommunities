import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { requireAdmin } from '../lib/auth.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).send('Method not allowed.');
  if (!requireAdmin(req, res)) return;
  try {
    const script = await readFile(join(process.cwd(), 'admin.js'), 'utf8');
    res.setHeader('Content-Type', 'text/javascript; charset=utf-8');
    res.setHeader('Cache-Control', 'private, no-store, max-age=0');
    res.setHeader('X-Robots-Tag', 'noindex, nofollow, noarchive');
    return res.status(200).send(script);
  } catch {
    return res.status(500).send('Admin workspace is unavailable.');
  }
}
