import { createSession, hasAuthConfig, requireSameOrigin, safeEqual, setSessionCookie } from '../lib/auth.js';
import { redisCommand, hasRedisConfig } from '../lib/redis.js';

const WINDOW_SECONDS = 15 * 60;
const MAX_ATTEMPTS = 8;

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' });
  if (!requireSameOrigin(req, res)) return;
  if (!hasAuthConfig()) return res.status(503).json({ error: 'Admin login is not configured yet.' });
  if (!hasRedisConfig()) return res.status(503).json({ error: 'Admin storage is not configured yet.' });

  try {
    const forwarded = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 'unknown';
    const bucket = Math.floor(Date.now() / (WINDOW_SECONDS * 1000));
    const key = `sdc:login-attempts:${forwarded}:${bucket}`;
    const attempts = Number(await redisCommand('INCR', key));
    if (attempts === 1) await redisCommand('EXPIRE', key, String(WINDOW_SECONDS));
    if (attempts > MAX_ATTEMPTS) return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' });

    const username = String(req.body?.username || '').slice(0, 200);
    const password = String(req.body?.password || '').slice(0, 1024);
    const valid = safeEqual(username, process.env.ADMIN_USERNAME) && safeEqual(password, process.env.ADMIN_PASSWORD);
    if (!valid) return res.status(401).json({ error: 'The username or password is incorrect.' });

    await redisCommand('DEL', key);
    setSessionCookie(res, createSession(process.env.ADMIN_USERNAME));
    return res.status(200).json({ ok: true, redirect: '/admin' });
  } catch {
    return res.status(503).json({ error: 'Login is temporarily unavailable.' });
  }
}
