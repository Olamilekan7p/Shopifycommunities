import { getJson, getList, hasRedisConfig, replaceList, setJson } from '../../lib/redis.js';
import { requireAdmin, requireSameOrigin } from '../../lib/auth.js';

const CONTENT_KEYS = ['heroTitle', 'heroSubtitle', 'communityStat', 'tagline', 'categories', 'interests', 'stores', 'events', 'faqs'];

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (!requireAdmin(req, res)) return;
  if (!hasRedisConfig()) return res.status(503).json({ error: 'Admin storage is not configured yet.' });
  if (req.method !== 'GET' && req.method !== 'PUT') return res.status(405).json({ error: 'Method not allowed.' });
  if (req.method === 'PUT' && !requireSameOrigin(req, res)) return;

  try {
    if (req.method === 'GET') {
      const [content, submissions, members] = await Promise.all([
        getJson('sdc:site-content', {}),
        getList('sdc:submissions'),
        getList('sdc:members')
      ]);
      return res.status(200).json({ content, submissions, members });
    }

    const body = req.body || {};
    if (body.content !== undefined) {
      if (!body.content || typeof body.content !== 'object' || JSON.stringify(body.content).length > 500_000) return res.status(400).json({ error: 'Invalid site content.' });
      const content = Object.fromEntries(CONTENT_KEYS.filter(key => key in body.content).map(key => [key, body.content[key]]));
      await setJson('sdc:site-content', content);
    }
    if (body.submissions !== undefined) {
      if (!Array.isArray(body.submissions) || body.submissions.length > 10_000) return res.status(400).json({ error: 'Invalid submission list.' });
      await replaceList('sdc:submissions', body.submissions);
    }
    if (body.members !== undefined) {
      if (!Array.isArray(body.members) || body.members.length > 50_000) return res.status(400).json({ error: 'Invalid member list.' });
      await replaceList('sdc:members', body.members);
    }
    return res.status(200).json({ ok: true });
  } catch {
    return res.status(503).json({ error: 'Admin storage is temporarily unavailable.' });
  }
}
