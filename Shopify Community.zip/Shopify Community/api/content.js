import { getJson, hasRedisConfig } from '../lib/redis.js';

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed.' });
  if (!hasRedisConfig()) return res.status(200).json({});
  try {
    return res.status(200).json(await getJson('sdc:site-content', {}));
  } catch {
    return res.status(503).json({ error: 'Content is temporarily unavailable.' });
  }
}
